<template>
    <el-row class="container">
        <el-col :span="24" class="header">
            <el-col :span="10" class="logo" :class="collapsed?'logo-collapse-width':'logo-width'">
                {{collapsed?'':sysName}}
            </el-col>
            <el-col :span="10">
                <div class="tools" @click.prevent="collapse">
                    <i class="fa fa-align-justify"></i>
                </div>
            </el-col>
            <el-col :span="4" class="userinfo">
                <el-dropdown trigger="hover">
                    <span class="el-dropdown-link userinfo-inner"><img src="../assets/img/img.jpg" /> {{sysUserName}}</span>
                    <el-dropdown-menu slot="dropdown">
                        <el-dropdown-item>我的消息</el-dropdown-item>
                        <el-dropdown-item>设置</el-dropdown-item>
                        <el-dropdown-item divided @click.native="logout">退出登录</el-dropdown-item>
                    </el-dropdown-menu>
                </el-dropdown>
            </el-col>
        </el-col>
        <el-col :span="24" class="main">
            <aside :class="collapsed?'menu-collapsed':'menu-expanded'">
                <transition name="fade" mode="out-in">
                <el-menu :default-active="onRoutes" class="el-menu-vertical-demo" theme="dark" 
					 unique-opened router v-if="!collapsed">
                
                    <template v-for="item in items" v-if="!item.hidden">
                        <template v-if="item.subs">
                            <el-submenu :index="item.index">
                                <template slot="title">
                                    <i :class="item.icon"></i>{{ item.title }}</template>
                                <el-menu-item v-for="(subItem,i) in item.subs" :key="i" :index="subItem.index">{{ subItem.title }}
                                </el-menu-item>
                            </el-submenu>
                        </template>
                        <template v-else>
                            <el-menu-item :index="item.index">
                                <i :class="item.icon"  aria-hidden="true"></i>{{ item.title }}
                            </el-menu-item>
                        </template>
                    </template>
                </el-menu>
                <el-menu :default-active="onRoutes" class="el-menu-vertical-demo collapsed" theme="dark" 
					  router >
                
                    <template v-for="item in items" v-if="!item.hidden">
                        <template v-if="item.subs">
                            <el-submenu :index="item.index">
                                <template slot="title">
                                    <i :class="item.icon"></i></template>
                                <el-menu-item v-for="(subItem,i) in item.subs" :key="i" :index="subItem.index">{{ subItem.title }}
                                </el-menu-item>
                            </el-submenu>
                        </template>
                        <template v-else>
                            <el-menu-item :index="item.index">
                                <i :class="item.icon"  aria-hidden="true"></i>
                            </el-menu-item>
                        </template>
                    </template>
                </el-menu>
                </transition>
            </aside>
            <section class="content-container">
                <el-col :span="24" class="content-wrapper">
						<transition name="fade" mode="out-in">
							<router-view></router-view>
						</transition>
					</el-col>
            </section>
        </el-col>
    </el-row>
</template>

<script>



    export default {
        data() {
            return {
                sysName: 'Gofun',
                collapsed: false,
                sysUserName: 'hong10',
                sysUserAvatar: '',
                items: [
                        {
                            icon: 'fa fa-home',
                            index: 'system',
                            title: '主页'
                        },
                        {
                            icon: 'el-icon-search',
                            index: 'system',
                            title: '系统管理'
                        },
                        {
                            icon: 'el-icon-search',
                            index: 'order',
                            title: '订单处理'
                        },
                        {
                            icon: 'el-icon-menu',
                            index: 'remind',
                            title: '提醒管理',
                            subs: [
                                {
                                    index: 'basetable',
                                    title: '基础表格'
                                },
                                {
                                    index: 'vuetable',
                                    title: 'Vue表格组件'
                                }
                            ]
                        },
                        {
                            icon: 'el-icon-date',
                            index: '5',
                            title: '表单',
                            subs: [
                                {
                                    index: 'baseform',
                                    title: '基本表单'
                                },
                                {
                                    index: 'vueeditor',
                                    title: '编辑器'
                                },
                                {
                                    index: 'markdown',
                                    title: 'markdown'
                                },
                                {
                                    index: 'upload',
                                    title: '文件上传'
                                }
                            ]
                        },
                        {
                            icon: 'el-icon-star-on',
                            index: 'basecharts',
                            title: '图表'
                        },
                        {
                            icon: 'el-icon-upload2',
                            index: 'drag',
                            title: '拖拽'
                        }
                    ]
            }
        },

       
        computed: {
            onRoutes() {
                return this.$route.path.replace('/', '');
            }
        },
        methods: {
            logout: function() {
                var _this = this;
                this.$confirm('确认退出吗?', '提示', {
                    //type: 'warning'
                }).then(() => {
                    sessionStorage.removeItem('user');
                    _this.$router.push('/login');
                }).catch(() => {
                });
            },
            collapse:function(){
				this.collapsed=!this.collapsed;
			},
           
           

        }
    }
</script>
<style scoped>
    .container {
        position: absolute;
        top: 0px;
        bottom: 0px;
        width: 100%;
        left: 0px;
    }

    .header {
        height: 60px;
        line-height: 60px;
        background: #20a0ff;
        color: #fff;
    }

    .container .header .userinfo .userinfo-inner {
        cursor: pointer;
        color: #fff;
    }

    .container .header .userinfo {
        text-align: right;
        padding-right: 35px;
        float: right;
    }

    .container .header .userinfo .userinfo-inner img {
        width: 40px;
        height: 40px;
        border-radius: 20px;
        margin: 10px 0 10px 10px;
        float: right;
    }

    .main {
        display: flex;
        position: absolute;
        top: 60px;
        bottom: 0px;
        overflow: hidden;
    }

    .container .header .logo-width {
        width: 230px;
    }

    .logo-width {

        height: 60px;
        font-size: 22px;
        padding-left: 20px;
        padding-right: 20px;
        border-color: rgba(238, 241, 146, 0.3);
        border-right-width: 1px;
        border-right-style: solid;
    }

    .header .tools {
        padding: 0px 23px;
        width: 14px;
        height: 60px;
        line-height: 60px;
        cursor: pointer;
    }

    .logo-width img {
        width: 40px;
        float: left;
        margin: 10px 10px 10px 18px;
    }
    aside .fa {
        margin-right: 5px;
        width: 24px;
        text-align: center;
        color: #bfcbd9;
    }
    .logo-width .txt {
        color: #fff;
    }

    aside {
        flex: 0 0 230px;
        width: 230px;
    }

    aside .el-menu {
        height: 100%;
    }

    .collapsed {
        width: 60px;
    }

    .collapsed .item {
        position: relative;
    }

    .collapsed .submenu {
        position: absolute;
        top: 0px;
        left: 60px;
        z-index: 99999;
        height: auto;
        display: none;
    }

    .container .main .menu-collapsed {
        flex: 0 0 60px;
        width: 60px;
    }

      .container .main .menu-expanded {
        flex: 0 0 230px;
        width: 230px;
    }

    .content-container {

        flex: 1;

        overflow-y: scroll;
        padding: 20px;
    }

    .breadcrumb-container .title {
        width: 200px;
        float: left;
        color: #475669;
    }

    .breadcrumb-container .breadcrumb-inner {
        float: right;
    }

    .content-container .content-wrapper {
        background-color: #fff;
        box-sizing: border-box;
    }
</style>
