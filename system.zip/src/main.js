import Vue from 'vue'
import App from './App.vue'
import ElementUI from 'element-ui'
import VueRouter from 'vue-router'
import 'element-ui/lib/theme-default/index.css'
import routerConfig from './router.config.js'

Vue.use(ElementUI)
Vue.use(VueRouter)

import 'font-awesome/css/font-awesome.min.css'
const router = new VueRouter(routerConfig)
new Vue({
    router,
    el: '#app',
    render: h => h(App)
})