import Login from './components/Login.vue'
import Home from './components/Home.vue'
import System from './components/system/System.vue'
import Order from './components/order/Order.vue'
import WorkOrder from './components/workorder/WorkOrder.vue'


export default {
    routes: [
        { path: '/', redirect: '/login' },
        {
            path: '/readme',
            component: Home,
            children: [
                { path: '/system', component: System, name: '系统管理' },
                { path: '/order', component: Order, name: '订单管理' },
                { path: '/workorder', component: WorkOrder, name: '工单管理' }
            ]



        },
        { path: '/login', component: Login }


    ]
}