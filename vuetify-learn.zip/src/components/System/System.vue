<template>
  <v-container fluid>
    <v-layout row>
      <v-flex xs6 order-lg2>
        <v-card dark tile flat class="error">
          <v-card-text>Here is System</v-card-text>
        </v-card>
      </v-flex>
      <v-flex xs6>
        <v-card dark tile flat class="red darken-4">
          <v-card-text>#2</v-card-text>
        </v-card>
      </v-flex>
    </v-layout>
    
    
  </v-container>
</template>
